//for (var i = 0; i < E; i++)
//{
//document.write(" "+ caminho[i]);
//}
/**
 * IMPORTANT: This only works with the canvas renderer. TBD in the future
 * will also support the WebGL renderer.
 */

sigma.utils.pkg('sigma.canvas.nodes');

// generate a random graph
var i, nfam,node = [],type2,
    s,
    img,
   // N = 50,
   // E = 50,
   
    urls = [
      'img/mito.PNG',
      'img/matheus.PNG',
      'img/fornaza.PNG',
      'img/Claudio.png',
      'img/img1.png',
      'img/img2.png',
      'img/img3.png',
      'img/img4.png',
      'img/img5.png',
      'img/img6.png',
      'img/img7.png',
      'img/img8.png',
      'img/img9.png',
      'img/img1.png',
      'img/img2.png',
      'img/img3.png',
      'img/img4.png',
      'img/img5.png',
      'img/img6.png',
      'img/img7.png',
      'img/img8.png',
      
      'img/img9.png'
    ],
    colors = [
      '#008000',
      '#4B0082',
      '#F08080',
      '#FF00FF',
      '#800000',
      '#617db4',
      '#668f3c',
      '#c6583e',
      '#b956af',
      '#00FFFF',
      '#00008B',
      '#FFD700',
      '#c6583e',
      '#b956af',
      '#00FFFF',
      '#00008B',
      '#FFD700',
      
      '#c6583e',
      '#b956af',
      '#00FFFF',
      '#00008B',
      '#FFD700',
      '#c6583e',
      '#b956af',
      '#00FFFF',
      '#00008B',
      '#008000',
      '#4B0082',
      '#F08080',
      '#FF00FF',
      '#800000',
      '#617db4',
      '#668f3c',
      '#c6583e',
      '#b956af',
      '#00FFFF',
      '#00008B',
      '#FFD700',
      '#c6583e',
      '#b956af',
      '#00FFFF',
      '#00008B',
      '#FFD700',
      
      '#c6583e',
      '#b956af',
      '#00FFFF',
      '#00008B',
      '#FFD700',
      '#c6583e',
      '#b956af',
      '#00FFFF',
      '#00008B',
      '#FFD700',
      '#00FF7F'
      
    ];
var nfam =0;
// Generate a random graph, going through the different shapes
//var nfam =-1;
//var t2pe:ShapeLibrary.enumerate().map(function(s){return s.name;})[Math.round(Math.random()*5)];
for (i = 0; i < N; i++) {
  

// node_aux[i][0];
if (i>0) {
if  (node_aux[i-1][0] != nfam ){
 var famcol ='#FF00FF',// colors[Math.floor(Math.random() * colors.length)],
 nfam= node_aux[i][0],
  fambcol= '#00FF7F',// colors[Math.floor(Math.random()* colors.length*4)],
sizefam=Math.random();
type2:ShapeLibrary.enumerate().map(function(s){return s.name;})[Math.round(Math.random()*5)],

node.image = {
     // url: urls[Math.floor(Math.random() * urls.length)],
    // ***tirei para deixar limpo  url:urls[ node_aux[i][0]],
      // scale/clip are ratio values applied on top of 'size'
      scale: 1,
      clip: 100
      
    };
    
}  } else { //primeiro elemento
  
 var famcol = colors[node_aux[i][1]],
 nfam= node_aux[i][0],
  fambcol= colors[node_aux[i][1]],
sizefam=Math.random();
type2:ShapeLibrary.enumerate().map(function(s){return s.name;})[Math.round(Math.random()*4)],

node.image = {
      // ** tirei para deixar limpo url:urls[ node_aux[i][0]],// urls[node_aux[i][0]],//[Math.floor(Math.random() * urls.length)],
      // scale/clip are ratio values applied on top of 'size'
      scale: 1,
      clip: 100
      
} }

   node = {
    //type : type2, 
   type: ShapeLibrary.enumerate().map(function(s){return s.name;})[node_aux[i][0]%20],
    //ShapeLibrary.enumerate().map(function(s){return s.name;})[node_aux[i][0]%4)],
    id: 'n' + i,
    label: 'nó ' + i + '('+node_aux[i][0] +')' ,
  
    x: node_aux[i][1],
    y: node_aux[i][2],
    size:10, // Math.random(),
    color: colors[node_aux[i][0]], 
    borderColor:  '#FFD700'  //fambcol
  };
  node.image = {
  //** tirei para deixar limpo */  url:urls[ node_aux[i][0]],// urls[node_aux[i][0]],//[Math.floor(Math.random() * urls.length)],
    // scale/clip are ratio values applied on top of 'size'
    scale: 1,
    clip: 100
    
} ;

 //if(Math.random()>0.75 && node.type!='pacman') { // ~0.75 of the (non-pacman)shapes will have an image
  
  //}

  switch(node.type) {
    case "equilateral":
      node.equilateral = {
        //rotate: Math.random()*45, // random rotate up to 45 deg
        //numPoints: Math.round(5 + Math.random()*3)
      }
      break;
    case "star":
      node.star = {
       // innerRatio: 0.4 + Math.random()*0.2,
        //numPoints: Math.round(4 + Math.random()*3)
      }
      if(node.image) {
        // note clip/scale are ratio values. So we fit them to the inner ratio of the star shape
        //node.image.clip = node.star.innerRatio *0.95;
        //node.image.scale = node.star.innerRatio *1.2;
      }
      break;
    case "square":
    case "diamond":
      if(node.image) {
        // note clip/scale are ratio values. So we fit them to the borders of the square shape
        node.image.clip = 0.7;
      }
      break;
    case "circle":
      break;
    case "cross":
      node.cross = {
   //     lineWeight: Math.round(Math.random() * 5)
      }
      break;
  } 


  g.nodes.push(node);
}



for (i = 0; i < E; i++)
{
 
  g.edges.push({
    id: 'e' + i,
   
   
    source:'n' + (caminho[i]|0), //'n' + (Math.random() * N | 0),
    target:'n' + (caminho[(i+1)]|0), //'n' + (Math.random() * N | 0),
    size: 0.001 //Math.random()
  });
}

s = new sigma({
  graph: g,
  renderer: {
    container: document.getElementById('graph-container'),
    type: 'canvas'
  },
  settings: {
    minNodeSize: 15,
    maxNodeSize: 15,
  }
});
CustomShapes.init(s);
s.refresh();

